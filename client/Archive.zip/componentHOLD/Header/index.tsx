import React, { Fragment, useContext } from "react";
import { ModalToggler } from "@faceless-ui/modal";
import Link from "next/link";
import { useGlobals, GlobalsContext } from "../../providers/Globals";
import { Gutter } from "../Gutter";
import { MenuIcon } from "../../components/icons/Menu";
import { CMSLink } from "../Link";
import { Logo } from "../../components/Logo";
import { MobileMenuModal, slug as menuModalSlug } from "./MobileMenuModal";

import classes from "./index.module.scss";

type HeaderBarProps = {
  children?: React.ReactNode;
};

export const HeaderBar: React.FC<HeaderBarProps> = ({ children }) => {
  return (
    <header className={classes.header}>
      <Gutter className={classes.wrap}>
        <Link href="/">
          <Logo />
        </Link>

        {children}

        <ModalToggler
          slug={menuModalSlug}
          className={classes.mobileMenuToggler}
        >
          <MenuIcon />
        </ModalToggler>
      </Gutter>
    </header>
  );
};

export const Header: React.FC = () => {
  const navItems = useGlobals().mainMenu?.navItems;

  return (
    <Fragment>
      <HeaderBar>
        <nav className={classes.nav}>
          {navItems?.map(({ link }, i) => {
            return <CMSLink key={i} {...link} />;
          })}
        </nav>
      </HeaderBar>

      <MobileMenuModal navItems={navItems} />
    </Fragment>
  );
};
